#!/usr/bin/env bash
set -euo pipefail
TS=$(date -u +%Y-%m-%dT%H:%M:%SZ)
END=$(date -u -d "+2 minutes" +%Y-%m-%dT%H:%M:%SZ)
cat >/tmp/test-alert.json <<EOF
[
  {"labels":{"alertname":"TestEmail","severity":"warning"},
   "annotations":{"summary":"Test email via Alertmanager (Gmail)"},
   "startsAt":"$TS","endsAt":"$END"}
]
EOF
curl -s -X POST -H "Content-Type: application/json" --data-binary @/tmp/test-alert.json http://127.0.0.1:9093/api/v2/alerts; echo
