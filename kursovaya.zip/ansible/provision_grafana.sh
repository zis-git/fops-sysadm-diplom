#!/usr/bin/env bash
set -euo pipefail
CN=$(docker ps --filter "publish=3000" | awk 'NR==2{print $NF}')
if [[ -z "${CN:-}" ]]; then
  CN=$(docker ps | awk '$2 ~ /grafana\/grafana/ {print $NF; exit}')
fi
echo "Grafana container: $CN"
[ -n "$CN" ]

docker exec -u 0 "$CN" mkdir -p /etc/grafana/provisioning/dashboards /var/lib/grafana/dashboards
docker cp /tmp/kursovaya_provider.yml  "$CN":/etc/grafana/provisioning/dashboards/kursovaya.yml
docker cp /tmp/kursovaya-nginx.json   "$CN":/var/lib/grafana/dashboards/kursovaya-nginx.json

# uid/gid grafana внутри контейнера обычно 472
docker exec -u 0 "$CN" sh -c 'chown -R 472:472 /var/lib/grafana/dashboards || true'

docker restart "$CN"
