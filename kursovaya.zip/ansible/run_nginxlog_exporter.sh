#!/usr/bin/env bash
set -euo pipefail
docker rm -f nginxlog-exporter 2>/dev/null || true

IMAGES=(
  ghcr.io/martin-helmich/prometheus-nginxlog-exporter:v1.11.0
  quay.io/martinhelmich/prometheus-nginxlog-exporter:v1.11.0
  docker.io/martinhelmich/prometheus-nginxlog-exporter:v1.11.0
  docker.io/martin-helmich/prometheus-nginxlog-exporter:v1.11.0
)

IMAGE=""
for img in "${IMAGES[@]}"; do
  echo "Trying to pull $img..."
  if docker pull "$img" >/dev/null 2>&1; then
    IMAGE="$img"
    echo "Using $img"
    break
  fi
done

if [ -z "$IMAGE" ]; then
  echo "ERROR: failed to pull exporter image from all mirrors" >&2
  exit 1
fi

docker run -d --name nginxlog-exporter --restart unless-stopped \
  -p 4040:4040 \
  -v /etc/nginxlog_exporter.yml:/config.yml:ro \
  -v /var/log/nginx:/var/log/nginx:ro \
  "$IMAGE" \
  -config-file /config.yml

sleep 1
docker ps --format 'table {{.Names}}\t{{.Image}}\t{{.Status}}' | grep nginxlog-exporter || true
